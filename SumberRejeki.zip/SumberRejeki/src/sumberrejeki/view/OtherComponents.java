package sumberrejeki.view;

public interface OtherComponents {
    public void display();
}
