package sumberrejeki.view;

public interface Completing<S, T> {
    public void action(S s, T t);
    public void another(int counters, T t);
}
