package sumberrejeki.dao;

import javax.swing.DefaultComboBoxModel;

public interface Classification {
    public DefaultComboBoxModel dropdown(int id);
}
