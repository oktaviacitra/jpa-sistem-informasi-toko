package sumberrejeki.dao;

public interface FindByName<T> {
    public T findByName(String name);
}
